# %atom name,  amplitude, sigma
C    2 3
N    2 3  
O    2 3
H   0.25 2
