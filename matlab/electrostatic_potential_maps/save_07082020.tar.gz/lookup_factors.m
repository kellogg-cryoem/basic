function[sigma,amp] = lookup_factors(atomName,etable)
    %etable is a map
    return etable(atomName);
end